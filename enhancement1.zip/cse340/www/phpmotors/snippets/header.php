<header>
    <div>
        <img src="images/site/logo.png" alt="logo">
        <p><a id="account-link" href="">My Account</a></p>
    </div>
    <!--nav bar snippet-->
    <?php

    require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/nav.php'

    ?>
</header>